package co.edu.Unbosque.controller;

public class AplMain {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		
		Controller controlador = new Controller();
		
	}

}
